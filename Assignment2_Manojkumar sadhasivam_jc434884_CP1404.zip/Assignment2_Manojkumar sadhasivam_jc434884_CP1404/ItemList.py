class ItemList:

    def __init__(self, list):

        self.list = list


